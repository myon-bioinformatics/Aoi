import pandas as pd
C=pd.read_csv('npb12_comparison.csv',index_col=0); R=pd.read_csv('chunichi_npb12_ranks.csv'); X=pd.read_csv('counterexamples.csv')
L=["\n## 6. 12球団比較（NPB全体、2013-2025、チームシーズン単純平均）\n"]
keys=['win%','pythW_diff','R/G','RA/G','RD/G','1点差勝率','2点差勝率','3点差以上勝率','逆転勝/G','逆転負率(敗戦中)','ビハインド経験試合の勝率','13回得失差/G','46回得失差/G','79回得失差/G','5回終了リード率','5回終了リード_勝率','7回終了リード率','7回終了リード_勝率','ビジター勝率','ホーム勝率','勝利中1点差の割合','勝利中4点以上差の割合']
cols=['中日','NPB全体','NPB Aクラス','NPB Bクラス(中日除く)','CL Aクラス','PL Aクラス','中日の平均NPB順位(12球団)','中日がNPB10-12位の年数/13','中日がNPB下半分(7-12位)の年数/13']
L.append('| 指標 | '+' | '.join(cols)+' |'); L.append('|'+'---|'*(len(cols)+1))
for k in keys:
    L.append(f"| {k} | "+' | '.join('-' if pd.isna(C.loc[k,c]) else (f"{C.loc[k,c]:.1f}" if c.startswith('中日の') or c.startswith('中日が') else f"{C.loc[k,c]:.3f}") for c in cols)+' |')
L.append("\n## 7. 中日の12球団内順位（年度別、1=最良。逆転負率・失点は少ないほど上位）\n")
rc=['year','rank','1点差勝率','3点差以上勝率','逆転勝/G','ビハインド経験試合の勝率','13回得失差/G','79回得失差/G','5回終了リード_勝率','7回終了リード_勝率','ビジター勝率','pythW_diff','R/G','RA/G']
hdr=['年','CL順位','1点差勝率','3点差以上勝率','逆転勝/試合','ビハインド時勝率','1-3回得失','7-9回得失','5回リード時勝率','7回リード時勝率','ビジター勝率','ピタゴラス差','得点/試合','失点/試合']
L.append('| '+' | '.join(hdr)+' |'); L.append('|'+'---|'*len(hdr))
for _,x in R.iterrows():
    L.append('| '+' | '.join([f"{int(x.year)}{'※' if x.year in (2020,2026) else ''}",str(int(x['rank']))]+[str(int(x[c])) for c in rc[2:]])+' |')
L.append("\n※2026はセ・パとも10/3時点の暫定。中日は143試合すべて終了済み（10/3に3-1で勝ち、最終60-81-2）。他球団は一部の試合が未消化か進行中。")
P=X[X.league=='PL']
L.append("\n## 8. パ・リーグの「反例」チームシーズン（2013-2025）\n")
L.append("| 年 | 球団 | 順位 | 勝-敗-分 | 得失差 | 得点順位 | 失点順位 | ピタゴラス差 | 1点差勝率 | 区分 |"); L.append("|---|---|---|---|---|---|---|---|---|---|")
for _,x in P.iterrows():
    L.append(f"| {x.year} | {x.team} | {x['rank']} | {x.W}-{x.L}-{x['T']} | {x.RD:+d} | {int(x['得点順位'])} | {int(x['失点順位'])} | {x.pythW_diff:+.1f} | {x['1点差勝率']:.3f} | {x.tags} |")
open('report_npb12.md','w').write('\n'.join(L)); print('ok')
