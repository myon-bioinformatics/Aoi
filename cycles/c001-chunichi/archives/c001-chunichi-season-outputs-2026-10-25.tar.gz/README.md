# サイクル1: 中日ドラゴンズ

GENESIS.md の「Note On Evidence」で予告した、問いを生んだ観測の再構築。

## 最終ゴール

**中日ドラゴンズは、なぜ14年間 CS に進出できなかったのか。** その答えを出すこと。

命題の判定・異議・作り直しは、すべてこの問いに向かうための手段として行う。

**本題は「なぜ B クラス（4〜6位）が続いたのか」、つまり1〜3位になれなかった理由**（ユーザーの判断、2026-10-04）。CS の有無で例外を作るより、B クラスで定義する。2020年はこれまでどおり除外の例外として扱う。

**いまの到達点は [FINDINGS.md](FINDINGS.md)**（式・結果・弱めた見方・開いた問い）。全命題の最新の判定は [`outputs/index.md`](outputs/index.md)（自動生成）。

[PR #3 の訂正・未検証事項の引き継ぎ](research/PR3_FOLLOWUP.md)は、2026-10-04時点の履歴です。F1〜F7の現在の完了監査や、研究成果全体のmain統合を表すものではありません。

cycle-001/chunichi 先端の続き（R27以降の別系列、P115以降、追加の派生列、branch 側の pipeline）は [from-cycle-001/README.md](from-cycle-001/README.md) に、正本の入力ハッシュと P1〜P114 の判定を書き換えずに置いてあります。正本の `season.jsonl`・`analysis.toml`・`propositions.toml` は LittleBit holdout の固定入力のままです。


数え方の注意（結論を書くときに、どれで言っているかを必ず明示する）:

- CS 進出の条件は、6球団リーグでは3位以内。判定で使う `upper_half`（上位半分）と一致する
- 「14年間」は 2013〜2026年を指す（2012年は2位で進出）
- 2026年の CS 不出場は確定している（npb.jp の順位表、2026-10-02 時点: 中日 59勝81敗2分・残り1試合で最大 .4255、3位 DeNA は残り2試合を全敗しても .493）。最終順位（4〜6位のどれか）はまだ決まっていない。取得範囲（`pipeline.toml` の `years`）はシーズン終了後に 2012〜2026 に広げる
- 2020年は CS が開催されず、中日は3位。数え方で結果が変わる。下の値は外部レポート（`references/`）のもの。2026年の B クラス・CS 不出場は確定済み。実データで確かめる

| 数え方 | 結果 |
|---|---|
| 厳密な B クラス（2020年の3位は A クラス） | 14年中13年が B |
| 2020年を除く | 13シーズン連続 B |
| CS に出場していない | 14年連続（注） |

（注）2020年は CS が開催されていない。CS が開催された年に限れば、厳密には13年連続（2013〜2019、2021〜2026）。「14年連続」は、2013〜2026年の14シーズンで一度も CS に出場していない、という意味で使う。

## 問い

- 観測: 中日ドラゴンズは長いあいだ、セ・リーグの下位に位置するシーズンが続いた（**取得したデータで数え直す**。記憶では書かない）
- 問い: 既存の指標（得失点・ピタゴラス期待勝率）は、この結果を十分に説明しているか
- 順位: 偏りがなければ、各シーズンの順位の期待値は1〜6のどれも同じはず。下位（4〜6位）がどれだけ続いているかを観測する。CS の有無は扱わない（リーグによって制度が異なり、後からできた制度でもあるため）

## 範囲と判断

| 項目 | 内容 | 記録場所 |
|---|---|---|
| 期間 | 2012〜2025年の公式戦（交流戦を含む）。イニング単位は 2013〜2025年 | `pipeline.toml` の `years` |
| 取得元 | npb.jp の月別公式戦カレンダー（最終スコア）、チーム打撃成績 | `blueprobe/docs/npb_calendar.md`、`blueprobe/docs/npb_team_batting.md` |
| 外部の集計 | イニング単位の球団×年の集計（PR #3、GPT。試合数・得点をこちらの値と照合） | `references/pr3-inning-team-year-metrics.csv.gz` |
| 除外 | 2020年（理由は `analysis.toml`） | `outputs/exclusions.json` |
| 比較対象 | 全12球団（順位の検定はセ・リーグの6球団） | `analysis.toml` の `[focus]` |
| 保留 | 打席・走者の状態（残塁・盗塁死など）。Grok が取得中のプレー経過を待つ | `hypotheses.toml` |
| 命題 | P1〜P114（事前登録。読める識別子と指紋つき。結果を見た後に作ったものは `change`・`note` に明記） | `propositions.toml`、`outputs/index.md` |
| 条件の探索 | B クラスを言い当てる条件の組み合わせ（候補は探索の前に固定） | `rule_candidates.toml`、`outputs/rules.jsonl` |
| 潜在パターンの探索 | 候補マスクの LittleBit 分解から足した条件（#22）。探索の記録で、確かめは `confirmation.md` | `outputs/exploratory/littlebit-approx/` |
| 外部の主張 | 外部レポート・外部の会話・GPT・Grok の数値と解釈（C1〜C27） | `claims.toml`、`references/` |
| 研究計画 | R1〜R26（それぞれ計算の前に問い・方法・見直す条件・限界を記録し、結果を追記） | `research/` |

## 実行

```bash
python nagoyaction/nagoyaction.py doctor cycles/c001-chunichi/pipeline.toml
python nagoyaction/nagoyaction.py run    cycles/c001-chunichi/pipeline.toml --receipt data/receipts/c001.jsonl
```

GitHub 上では Actions の「cycle c001 (chunichi)」で実行する（main に入るまでは `run/c001` ブランチへの push で起動。結果はそのブランチにコミットされる）。中身は同じコマンド。
取得はカレンダー約126ページ＋打撃成績28ページ（3秒間隔）で、取得済みのページは取り直さない（Actions のキャッシュ。止まった実行でも保存する）。

## 成果物（`outputs/`、git で管理する）

| ファイル | 中身 |
|---|---|
| `index.md` | **全命題の一覧**（識別子・4つの形の判定・きっかけ以外での判定・親）。毎回自動で作り直す |
| `research_digest.jsonl` | R1〜R26の題名・記録日・命題ID・参照先・見直し条件と、**その時点の総合終了コード**。R18の事前登録基準と欠損・未抽出を区別する |
| `research_digest.md` | 上記ダイジェストの一覧・抽出診断・FINDINGSの限定的な転記照合（自動生成） |
| `confirmation.md` | **まだ使っていない年（2026年）での確かめ**。命題ごとに、その年の単位を成立・判例・逆の判例・どちらも当たらないに分けて数える（R18、`analysis.toml` の `[confirm]`） |
| `observed.md` | 年ごとの取得結果、採用しなかった件数、未知の表記（数字は伏せる）、試合数の照合 |
| `observed_batting.md` | チーム打撃成績の構造の確認（同上） |
| `season.jsonl` | チーム×シーズンの指標（派生値） |
| `cumulative.jsonl` | 期待勝率からのずれの累積と z 値 |
| `rank_test.jsonl` | 順位の偏りの検定（帰無仮説と全球団比較） |
| `exclusions.json` | 除外したシーズンと理由 |
| `summary.md` | 検証記録。観測した数だけを書き、原因は書かない |
| `objections.md` | 命題ごとの判定と「異議あり」（判例の一覧、除外中の判例） |
| `propositions.jsonl` | 同じ内容の機械向け形式（命題ファイルの SHA-256 とコードの版つき） |
| `sets.md` / `sets.jsonl` / `sets.junit.xml` | 命題の集合の式（branch 側 R48）。正本の命題判定とは別ファイル |
| `next.md` / `next.jsonl` | 次の命題の種。判定ではない |
| `observed_fielding.md` / `observed_linescore.md` | 守備・イニング得点の構造確認 |
| `provisional/` | 2026年の暫定観測。本体の集計へは入れない |
| `fetched/` | branch 側が残した取得台帳。正本の `data/` キャッシュとは別 |
| `claims.json` | 外部の主張の再現結果 |
| `allocation.jsonl` | 配分効果の期間合計（R1） |
| `persistence.jsonl` | 隣り合うシーズンの相関（配分効果・ピタゴラスのずれ・勝率） |
| `persistence_all.jsonl` / `persistence_by_team.jsonl` | 隣り合うシーズンの相関（得点した回の大きさ・得点の不足・A クラスの見込み・勝率、強い相手との試合の net・env）の全体とチームごと（R14・R19） |
| `rank_expectation.jsonl` | 得点・失点の分布から見た A クラスの回数の期待値と実際の回数（R10） |
| `trajectory_sensitivity.jsonl` / `trajectory_sensitivity_units.jsonl` | 線の始まりの試合数を変えたときの読み（R25）。群ごとのまとめと、単位ごとの値 |
| `trajectory_expectation.jsonl` | シーズンの中の順位・貯金の線（3次式）の山・谷の数と、順位の線に波のある式が選ばれた数を、力が一定のときの見込みと比べたもの（R22・R23） |
| `rules.jsonl` | B クラスを言い当てる条件の組み合わせの探索結果（R11） |
| `exploratory/littlebit-approx/` | 潜在パターン由来の条件を足した探索と、既存候補だけの探索の並び（#22）。確かめは `confirmation.md` |
| `rules_r21.jsonl` | 同じ探索に 2014年の道筋の条件を足し、「または」を3つまでにしたもの（R21、`rule_candidates_r21.toml`） |
| `ledger.jsonl` | 命題の判定の台帳 |
| `run.txt` | Actions の実行の記録（各ステップの結果・件数・エラー文） |

生のページ（`data/raw/`）と1試合ごとの観測（`data/observations/`）は git に入れない。
