import pandas as pd, numpy as np
P2='/workspace/dragons_analysis/part2'
I=pd.read_csv('team_half_innings.csv.gz')
D=pd.read_csv(f'{P2}/team_games.csv')[['url','team','home','opp']]
I=I.merge(D,on=['url','team'])
I['home_team']=np.where(I.home,I.team,I.opp)
I=I[(I.year<=2025)&(I.league=='CL')]
rows=[]
for t,x in I.groupby('team'):
    for side in ('off','def'):
        s=x[x.side==side]
        at_nag=s[s.home_team=='d']; neutral=s[(s.home_team!='d')&(s.home_team!=t)]
        rows.append(dict(team=t,side=side,SR_all=(s.runs>0).mean(),SR_nagoya=(at_nag.runs>0).mean(),SR_excl_Nagoya_and_own_home=(neutral.runs>0).mean(),
            RPI_all=s.runs.mean(),RPI_nagoya=at_nag.runs.mean(),RPI_neutral=neutral.runs.mean(),n_neutral=len(neutral)))
P=pd.DataFrame(rows); P.to_csv('park_check_CL_2013_2025.csv',index=False,encoding='utf-8-sig'); print(P.round(3).to_string())
# other CL teams: SR in games at Nagoya vs elsewhere (excluding own home)
