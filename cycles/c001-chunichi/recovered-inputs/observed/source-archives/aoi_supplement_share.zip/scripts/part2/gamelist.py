import os,re,glob,json
RAW='/workspace/dragons_analysis/part2/raw'
CL={'g','t','c','d','db','s'}
def games():
    out=[]
    for y in range(2013,2027):
        for p in sorted(glob.glob(f'{RAW}/{y}/days/gm*.html')):
            date=re.search(r'gm(\d{8})',p).group(1)
            s=open(p,encoding='utf-8').read()
            if y<=2025:
                for m in re.finditer(r'pet\d{4}_([a-z]+)_1\.gif.*?pet\d{4}_([a-z]+)_1\.gif.*?href="(s\d+\.html)"',s,re.S):
                    a,b,fn=m.groups()
                    out.append(dict(year=y,date=date,teams=[a,b],url=f'https://npb.jp/bis/{y}/games/{fn}',file=f'{RAW}/{y}/games/{fn}'))
            else:
                seen=set()
                for m in re.finditer(r'href="/scores/(\d{4})/(\d{4})/([a-z]+)-([a-z]+)-(\d+)/"',s):
                    yy,md,a,b,n=m.groups()
                    if yy!=str(y) or md!=date[4:] : continue
                    key=(md,a,b,n)
                    if key in seen: continue
                    seen.add(key)
                    out.append(dict(year=y,date=date,teams=[a,b],url=f'https://npb.jp/scores/{y}/{md}/{a}-{b}-{n}/',file=f'{RAW}/{y}/games/{md}_{a}-{b}-{n}.html'))
    # dedupe
    d={g['url']:g for g in out}
    return list(d.values())
def prio(g):
    t=set(g['teams'])
    return (0 if 'd' in t else 1 if t&CL else 2, g['year'], g['date'])
