# Validate regular-season trimming: (1) head-to-head game counts per pair match the NPB schedule format,
# (2) the page's "N回戦" label equals the running count of kept games for that pair, (3) trimmed games break that sequence.
import json,re,os,pandas as pd
from gamelist import games
CL={'g','t','c','d','db','s'}
G={g['url']:g for g in json.load(open('games_raw.json'))}
FILE={g['url']:g['file'] for g in games()}
D=pd.read_csv('team_games.csv'); P=pd.read_csv('excluded_postseason_games.csv')
def label(url):
    s=open(FILE[url],encoding='utf-8').read()
    m=re.search(r'gmdivnumber">\s*(\d+)回戦',s) or re.search(r'<h3>.*?(\d+)回戦.*?</h3>',s,re.S)
    return int(m.group(1)) if m else None
norm=lambda c:'b' if c=='bs' else c
rows=[]
for u,kind in [(u,'kept') for u in D.url.unique()]+[(u,'trimmed') for u in P.url.unique()]:
    g=G[u]; a,h=norm(g['away']),norm(g['home'])
    rows.append(dict(url=u,kind=kind,year=g['year'],date=g['date'],pair='-'.join(sorted([a,h])),inter=(a in CL)!=(h in CL),label=label(u)))
T=pd.DataFrame(rows).sort_values(['year','pair','date','url'])
K=T[T.kind=='kept'].copy(); K['seq']=K.groupby(['year','pair']).cumcount()+1
def expected(y,inter):
    if y==2020: return None if inter else 24
    if y in (2013,2014): return 4 if inter else 24
    return 3 if inter else 25
cnt=K.groupby(['year','pair','inter']).size().reset_index(name='n'); cnt['exp']=[expected(y,i) for y,i in zip(cnt.year,cnt.inter)]
badcnt=cnt[(cnt.year<=2025)&(cnt.n!=cnt.exp)]
K['label_ok']=K.label==K.seq
Tr=T[T.kind=='trimmed'].copy()
last=K.groupby(['year','pair']).seq.max()
Tr['kept_pair_games']=[last.get((y,p),0) for y,p in zip(Tr.year,Tr.pair)]
Tr['label_continues_regular']=Tr.label==Tr.kept_pair_games+1
out=pd.concat([K,Tr]); out.to_csv('trim_check_detail.csv',index=False)
k25=K[K.year<=2025]
summary=dict(kept_games_2013_2025=len(k25), pairs_checked=int((cnt.year<=2025).sum()), pairs_count_mismatch=len(badcnt),
     kept_label_match=int(k25.label_ok.sum()), kept_label_mismatch=int((~k25.label_ok).sum()), kept_label_missing=int(k25.label.isna().sum()),
     trimmed_games=len(Tr), trimmed_label_looks_like_regular_continuation=int(Tr.label_continues_regular.sum()),
     same_date_regular_and_trimmed_dates=int(len(set(Tr.date)&set(k25.date))))
print(summary); print(badcnt.to_string()); print(k25[~k25.label_ok].head(20).to_string())
print(Tr[Tr.label_continues_regular].to_string())
json.dump(summary,open('trim_check_summary.json','w'),indent=1)
