import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
S=pd.read_csv('team_season_summary.csv')
S['R/G']=S.R/S.G; S['RA/G']=S.RA/S.G; S['RD/G']=S.RD/S.G
for b in ['13','46','79']: S[f'{b}回得失差/G']=(S['r'+b]-S['a'+b])/S.G
S['延長得失差']=S.rx-S.ax
for k in (5,7):
    S[f'{k}回終了リード率']=S[f'{k}回終了リード_試合']/S.G
    S[f'{k}回終了ビハインド率']=S[f'{k}回終了ビハインド_試合']/S.G
S['完封勝/G']=S['完封勝']/S.G; S['完封負/G']=S['完封負']/S.G
S['逆転勝/G']=S['逆転勝']/S.G; S['逆転負/G']=S['逆転負']/S.G
S['1点差試合率']=S['1点差W-L'].map(lambda s: sum(map(int,s.split('-'))))/S.G
# metric: (column, higher_is_better or None for neutral)
M=[('win%',1),('pyth%',1),('pythW_diff',1),('R/G',1),('RA/G',0),('RD/G',1),
   ('1-3回得失差/G'.replace('1-3','13'),1),('46回得失差/G',1),('79回得失差/G',1),('前半(1-5回)得失差/試合',1),('後半(6回-)得失差/試合',1),
   ('逆転勝/G',1),('逆転負/G',0),('逆転勝率(勝利中)',None),('逆転負率(敗戦中)',0),('リード経験試合の勝率',1),('ビハインド経験試合の勝率',1),
   ('1点差勝率',1),('2点差勝率',1),('3点差以上勝率',1),('4点差以上勝率',1),('1点差試合率',None),
   ('勝利中1点差の割合',None),('勝利中2点差の割合',None),('勝利中3点差の割合',None),('勝利中4点以上差の割合',None),
   ('敗戦中1点差の割合',None),('敗戦中2点差の割合',None),('敗戦中4点以上差の割合',None),
   ('5回終了リード率',1),('5回終了リード_勝率',1),('5回終了同点_勝率',1),('5回終了ビハインド_勝率',1),
   ('7回終了リード率',1),('7回終了リード_勝率',1),('7回終了同点_勝率',1),('7回終了ビハインド_勝率',1),
   ('延長勝率',1),('完封勝/G',1),('完封負/G',0),('ホーム勝率',1),('ビジター勝率',1),('交流戦勝率',1)]
cols=[c for c,_ in M]
for c,hb in M:
    if hb is None: continue

    for (y,lg),idx in S.groupby(['year','league']).groups.items():
        S.loc[idx,c+'_順位']=S.loc[idx,c].rank(ascending=(hb==0),method='min')
S.to_csv('team_season_metrics.csv',index=False,encoding='utf-8-sig')
CL=S[S.league=='CL']
D=CL[CL.team=='d'].set_index('year')
# 1) Chunichi per season with CL rank
out=[]
for y,r in D.iterrows():
    row={'year':y,'順位':int(r['rank']),'W-L-T':f"{int(r.W)}-{int(r.L)}-{int(r['T'])}"}
    for c,hb in M:
        row[c]=r[c]
        if hb is not None: row[c+'(CL順位)']=r[c+'_順位']
    out.append(row)
pd.DataFrame(out).to_csv('chunichi_by_season.csv',index=False,encoding='utf-8-sig')
# 2) pooled comparison 2013-2025 (excluding 2026 provisional); also excl 2020
def pooled(df):
    return df[cols].mean()
yrs=CL.year<=2025
grp={'中日(2013-25平均)':CL[yrs&(CL.team=='d')],'CL Aクラス平均':CL[yrs&CL.Aclass],'CL Bクラス平均':CL[yrs&~CL.Aclass],'CL Bクラス(中日除く)':CL[yrs&~CL.Aclass&(CL.team!='d')],'CL 4位平均':CL[yrs&(CL['rank']==4)],'CL 3位平均':CL[yrs&(CL['rank']==3)],'CL全体':CL[yrs]}
if (S.league=='PL').any():
    full=S[S.league=='PL'].groupby('year').G.min(); okY=[y for y,g in full.items() if y<=2025 and g>=(120 if y==2020 else 143)]
    P=S[(S.league=='PL')&S.year.isin(okY)]
    print('PL complete seasons',okY)
    grp['PL Aクラス平均']=P[P.Aclass]; grp['PL Bクラス平均']=P[~P.Aclass]
C=pd.DataFrame({k:pooled(v) for k,v in grp.items()})
C['中日−A']=C.iloc[:,0]-C['CL Aクラス平均']; C['中日−B(中日除く)']=C.iloc[:,0]-C['CL Bクラス(中日除く)']
# chunichi avg rank across seasons
C['中日の平均CL順位']=[D.loc[D.index<=2025,c+'_順位'].mean() if (c+'_順位') in D else np.nan for c in cols]
C['中日がCL下位2(5-6位)の年数/13']=[(D.loc[D.index<=2025,c+'_順位']>=5).sum() if (c+'_順位') in D else np.nan for c in cols]
C.to_csv('class_comparison.csv',encoding='utf-8-sig')
# 3) counterexamples
X=S[S.year<=2025].copy()
X['得点順位']=X['R/G_順位']; X['失点順位']=X['RA/G_順位']
ce=[]
for _,r in X.iterrows():
    tags=[]
    if r.Aclass and r['得点順位']>=5: tags.append('得点リーグ5-6位でもAクラス')
    if r.Aclass and r.RD<0: tags.append('得失点差マイナスでもAクラス')
    if (not r.Aclass) and r.RD>0: tags.append('得失点差プラスでもBクラス')
    if (not r.Aclass) and r['得点順位']<=2: tags.append('得点リーグ1-2位でもBクラス')
    if tags: ce.append(dict(year=r.year,league=r.league,team=r['name'],rank=r['rank'],W=r.W,L=r.L,T=r['T'],R=r.R,RA=r.RA,RD=r.RD,得点順位=r['得点順位'],失点順位=r['失点順位'],pythW_diff=round(r.pythW_diff,1),**{'1点差勝率':round(r['1点差勝率'],3)},tags=' / '.join(tags)))
pd.DataFrame(ce).sort_values(['tags','year']).to_csv('counterexamples.csv',index=False,encoding='utf-8-sig')
print(C.round(3).to_string())
print(pd.DataFrame(ce).groupby('tags').size())
