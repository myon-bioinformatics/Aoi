#!/bin/bash
# resumable: cached pages are skipped
cd /workspace/dragons_analysis/part2
python3 crawl_games.py 3 >> games2.log 2>&1
python3 parse.py && python3 analyze.py && python3 benchmark.py && python3 report.py && python3 verify_official.py && python3 benchmark12.py >/dev/null && python3 report12.py && cat report_head.md report_tables.md report_npb12.md > report.md
