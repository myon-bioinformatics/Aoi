import re,html,pandas as pd
from parse import name2code
O='raw/official'
def rows(fn):
    from bs4 import BeautifulSoup
    soup=BeautifulSoup(open(f'{O}/{fn}',encoding='utf-8',errors='ignore').read(),'lxml'); out=[]
    for tr in soup.find_all('tr'):
        tds=[td.get_text('',strip=True) for td in tr.find_all('td',recursive=False)]
        tds=[t for t in tds if t!='']
        if len(tds)<6: continue
        try: c=name2code(tds[0])
        except Exception: continue
        out.append((c,tds))
    return out
rec=[]
for y in range(2013,2026):
    for lg in 'cp':
        std={}
        for c,t in rows(f'{y}_std_{lg}.html'): std.setdefault(c,t)
        tmb={}
        for c,t in rows(f'{y}_tmb_{lg}.html'): tmb.setdefault(c,t)
        tmp={}
        for c,t in rows(f'{y}_tmp_{lg}.html'): tmp.setdefault(c,t)
        for c,t in std.items():
            nums=[x for x in t[1:] if re.fullmatch(r'\d+',x)]
            G,W,L,T=map(int,nums[:4])
            R=int(tmb[c][5]); RA=int(tmp[c][-2])
            rec.append(dict(year=y,team=c,oG=G,oW=W,oL=L,oT=T,oR=R,oRA=RA))
O_=pd.DataFrame(rec)
S=pd.read_csv('team_season_summary.csv')[['year','team','G','W','L','T','R','RA']]
M=O_.merge(S,on=['year','team'],how='left')
M['ok']=(M.oG==M.G)&(M.oW==M.W)&(M.oL==M.L)&(M.oT==M['T'])&(M.oR==M.R)&(M.oRA==M.RA)
M.to_csv('official_check.csv',index=False)
print(len(M),'team-seasons; all match:',M.ok.all()); print(M[~M.ok].to_string())
