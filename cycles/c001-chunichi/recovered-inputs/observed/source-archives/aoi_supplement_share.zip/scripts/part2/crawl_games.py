import os,time,requests,threading,queue,sys
from gamelist import games,prio
S=requests.Session(); S.headers['User-Agent']='Mozilla/5.0 (personal research; polite crawler, ~2 req/s)'
gl=sorted(games(),key=prio)
gl=[g for g in gl if not os.path.exists(g['file'])]
print('todo',len(gl),flush=True)
q=queue.Queue(); [q.put(g) for g in gl]
lock=threading.Lock(); done=[0]
def w():
    s=requests.Session(); s.headers.update(S.headers)
    while True:
        try: g=q.get_nowait()
        except queue.Empty: return
        for t in range(4):
            try:
                r=s.get(g['url'],timeout=30); time.sleep(0.5)
                if r.status_code==404: print('404',g['url'],flush=True); break
                if r.ok:
                    r.encoding='utf-8'; os.makedirs(os.path.dirname(g['file']),exist_ok=True)
                    open(g['file'],'w',encoding='utf-8').write(r.text); break
            except Exception as e: print('ERR',g['url'],e,flush=True)
            time.sleep(5*(t+1))
        with lock:
            done[0]+=1
            if done[0]%200==0: print('done',done[0],flush=True)
ts=[threading.Thread(target=w) for _ in range(int(sys.argv[1]) if len(sys.argv)>1 else 2)]
[t.start() for t in ts]; [t.join() for t in ts]; print('finished',flush=True)
