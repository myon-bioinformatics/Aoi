import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
M=pd.read_csv('team_season_inning_metrics.csv')
pd.set_option('display.width',250)
Y=M[M.year<=2025]; d=Y[Y.team=='d']
cols=['R/G','off_innings_per_G','off_scoring_rate','off_runs_per_scoring_inn','off_one_run_share','off_r2_share','off_r3_share','off_r4p_share','off_big_inning_rate','off_scoreless_rate',
      'RA/G','def_innings_per_G','def_scoring_rate','def_runs_per_scoring_inn','def_one_run_share','def_big_inning_rate','def_scoreless_rate']
grp={'中日':d,'CL平均':Y[Y.league=='CL'],'NPB平均':Y,'NPB Aクラス':Y[Y.Aclass],'NPB Bクラス':Y[~Y.Aclass],'CL Aクラス':Y[(Y.league=='CL')&Y.Aclass]}
C=pd.DataFrame({k:v[cols].mean() for k,v in grp.items()})
for c in cols:
    if c+'_CL/PL順位' in M:
        C.loc[c,'中日 平均CL順位(6)']=d[c+'_CL/PL順位'].mean(); C.loc[c,'CL下半分(4-6位)年数/13']=(d[c+'_CL/PL順位']>=4).sum()
        C.loc[c,'中日 平均NPB順位(12)']=d[c+'_NPB順位'].mean(); C.loc[c,'NPB下半分(7-12位)年数/13']=(d[c+'_NPB順位']>=7).sum()
C.to_csv('chunichi_vs_groups.csv',encoding='utf-8-sig'); print(C.round(3).to_string())
# by inning scoreless (offense) & home/away
bi=[c for c in M.columns if c.startswith('off_scoreless_') and '回' in c]+['off_scoring_rate_away_bat','off_scoring_rate_home_bat']
B=pd.DataFrame({k:v[bi].mean() for k,v in grp.items()}); B.to_csv('by_inning_comparison.csv',encoding='utf-8-sig'); print(B.round(3).to_string())
bid=[c.replace('off_','def_') for c in bi]
Bd=pd.DataFrame({k:v[bid].mean() for k,v in grp.items()}); Bd.to_csv('by_inning_comparison_def.csv',encoding='utf-8-sig'); print(Bd.round(3).to_string())
# --- log decomposition vs pooled league average per year
def pooled(df,side):
    I=df[f'{side}_innings'].sum(); Sx=df[f'{side}_scoring'].sum(); R=df[f'{side}_runs'].sum(); G=df.G.sum()
    return dict(IG=I/G, SR=Sx/I, RPS=R/Sx, RG=R/G)
dec=[]
for y in sorted(M.year.unique()):
    t=M[M.year==y]; c=t[t.team=='d']
    for side in ('off','def'):
        me=pooled(c,side)
        for ref,rt in (('CL',t[t.league=='CL']),('NPB',t)):
            lg=pooled(rt,side)
            comp={k:np.log(me[k]/lg[k]) for k in ('IG','SR','RPS','RG')}
            dec.append(dict(year=y,side=side,ref=ref,中日RG=me['RG'],基準RG=lg['RG'],log_gap=comp['RG'],イニング数=comp['IG'],得点イニング率=comp['SR'],得点イニング当たり得点=comp['RPS'],
                 SR中日=me['SR'],SR基準=lg['SR'],RPS中日=me['RPS'],RPS基準=lg['RPS']))
Dc=pd.DataFrame(dec)
# pooled 2013-2025 (sum of log gaps)
Dc.to_csv('decomposition_by_year.csv',index=False,encoding='utf-8-sig')
for side in ('off','def'):
  for ref in ('CL','NPB'):
    x=Dc[(Dc.side==side)&(Dc.ref==ref)&(Dc.year<=2025)]
    s=x[['log_gap','イニング数','得点イニング率','得点イニング当たり得点']].sum()
    print(side,ref,'sum log gap',round(s.log_gap,3),'shares:',(s[1:]/s.log_gap).round(3).to_dict())
print(Dc[(Dc.side=='off')&(Dc.ref=='CL')].round(3).to_string())
print(Dc[(Dc.side=='def')&(Dc.ref=='CL')].round(3).to_string())
# --- NPB-wide variance decomposition of log(R/G) relative to year mean
for side,rg in (('off','R/G'),('def','RA/G')):
    Z=Y.copy()
    Z['lRG']=np.log(Z[rg]); Z['lIG']=np.log(Z[f'{side}_innings_per_G']); Z['lSR']=np.log(Z[f'{side}_scoring_rate']); Z['lRPS']=np.log(Z[f'{side}_runs_per_scoring_inn'])
    for c in ['lRG','lIG','lSR','lRPS']: Z[c]=Z[c]-Z.groupby('year')[c].transform('mean')
    v=Z.lRG.var(); print(side,'variance shares (cov/var):',{c:round(Z[c].cov(Z.lRG)/v,3) for c in ['lIG','lSR','lRPS']}, 'corr SR~RPS',round(Z.lSR.corr(Z.lRPS),3))
