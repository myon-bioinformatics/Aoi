import json, pandas as pd, numpy as np
from collections import defaultdict
CL={'g','t','c','d','db','s'}; PL={'l','f','m','b','h','e'}
NAME={'g':'巨人','t':'阪神','c':'広島','d':'中日','db':'DeNA','s':'ヤクルト','l':'西武','f':'日本ハム','m':'ロッテ','b':'オリックス','h':'ソフトバンク','e':'楽天'}
norm=lambda c:'b' if c=='bs' else c
G=json.load(open('games_raw.json'))
G=[g for g in G if g['status']=='final' and not any(k in g['title'] for k in ('クライマックス','日本シリーズ','オールスター'))]
recs=[]; dup=set()
for g in G:
    a,h=norm(g['away']),norm(g['home'])
    key=(g['date'],a,h,tuple(map(str,g['away_inn'])),tuple(map(str,g['home_inn'])))
    if key in dup: continue
    dup.add(key)
    ai=[v if isinstance(v,int) else 0 for v in g['away_inn']]
    hi=[v if isinstance(v,int) else 0 for v in g['home_inn']]
    n=max(len(ai),len(hi))
    # half-inning end states (away-home diff)
    states=[];ca=ch=0
    for i in range(n):
        if i<len(g['away_inn']) and g['away_inn'][i] is not None: ca+=ai[i]; states.append((i+1,'T',ca,ch))
        if i<len(g['home_inn']) and g['home_inn'][i] is not None:
            ch+=hi[i]; states.append((i+1,'B',ca,ch))
    for side,opp in (('away','home'),('home','away')):
        me=ai if side=='away' else hi; op=hi if side=='away' else ai
        R=g[side+'_R']; RA=g[opp+'_R']
        diffs=[(s[2]-s[3])*(1 if side=='away' else -1) for s in states]
        def after(k):
            # diff at end of inning k (after bottom k, or after top k if bottom not played)
            v=[ (s[2]-s[3])*(1 if side=='away' else -1) for s in states if s[0]<=k]
            return v[-1] if v else 0
        res='W' if R>RA else 'L' if R<RA else 'T'
        blk=lambda lo,hi_,arr: sum(arr[lo-1:hi_])
        recs.append(dict(year=g['year'],date=g['date'],team=norm(g[side]),opp=norm(g[opp]),home=side=='home',
            league='CL' if norm(g[side]) in CL else 'PL', inter=(norm(g[side]) in CL)!=(norm(g[opp]) in CL),
            R=R,RA=RA,res=res,margin=abs(R-RA),innings=n,
            ever_led=any(d>0 for d in diffs), ever_trailed=any(d<0 for d in diffs),
            d5=after(5), d7=after(7), d6=after(6),
            r13=blk(1,3,me),r46=blk(4,6,me),r79=blk(7,9,me),rx=sum(me[9:]),
            a13=blk(1,3,op),a46=blk(4,6,op),a79=blk(7,9,op),ax=sum(op[9:]),
            r15=blk(1,5,me),a15=blk(1,5,op),r6p=sum(me[5:]),a6p=sum(op[5:]),url=g['url']))
D=pd.DataFrame(recs)
SEASON_G={**{y:144 for y in (2013,2014)},**{y:143 for y in range(2015,2027)},2020:120}
D=D.sort_values(['year','team','date','url'])
D['gno']=D.groupby(['year','team']).cumcount()+1
post=D[D.gno>D.year.map(SEASON_G)]
post.to_csv('excluded_postseason_games.csv',index=False)
D=D[D.gno<=D.year.map(SEASON_G)].copy()
D.to_csv('team_games.csv',index=False)
def wpct(w,l): return w/(w+l) if w+l else np.nan
def summarize(x):
    W=(x.res=='W');L=(x.res=='L');T=(x.res=='T')
    o={}
    o['G']=len(x);o['W']=W.sum();o['L']=L.sum();o['T']=T.sum();o['win%']=wpct(W.sum(),L.sum())
    o['R']=x.R.sum();o['RA']=x.RA.sum();o['RD']=o['R']-o['RA']
    o['pyth%']=o['R']**1.83/(o['R']**1.83+o['RA']**1.83)
    o['pythW_diff']=o['W']-o['pyth%']*(o['W']+o['L'])
    o['逆転勝']= (W&x.ever_trailed).sum(); o['先行逃切勝']=(W&~x.ever_trailed).sum()
    o['逆転負']=(L&x.ever_led).sum(); o['完敗(一度もリードなし)']=(L&~x.ever_led).sum()
    o['逆転勝率(勝利中)']=o['逆転勝']/o['W'] if o['W'] else np.nan
    o['逆転負率(敗戦中)']=o['逆転負']/o['L'] if o['L'] else np.nan
    led=x.ever_led; tr=x.ever_trailed
    o['リード経験試合の勝率']=wpct((W&led).sum(),(L&led).sum())
    o['ビハインド経験試合の勝率']=wpct((W&tr).sum(),(L&tr).sum())
    for k,m in (('1点差',x.margin==1),('2点差',x.margin==2),('3点差以上',x.margin>=3),('4点差以上',x.margin>=4)):
        o[k+'W-L']=f"{(W&m).sum()}-{(L&m).sum()}"; o[k+'勝率']=wpct((W&m).sum(),(L&m).sum())
    for k,m in (('1点',x.margin==1),('2点',x.margin==2),('3点',x.margin==3),('4点以上',x.margin>=4)):
        o['勝利中'+k+'差の割合']=(W&m).sum()/W.sum() if W.sum() else np.nan
        o['敗戦中'+k+'差の割合']=(L&m).sum()/L.sum() if L.sum() else np.nan
    for c in ['r13','r46','r79','rx','a13','a46','a79','ax','r15','a15','r6p','a6p']: o[c]=x[c].sum()
    o['前半(1-5回)得失差/試合']=(o['r15']-o['a15'])/len(x); o['後半(6回-)得失差/試合']=(o['r6p']-o['a6p'])/len(x)
    for k in (5,7):
        dk=x['d%d'%k]
        for st,m in (('リード',dk>0),('同点',dk==0),('ビハインド',dk<0)):
            o[f'{k}回終了{st}']=f"{(W&m).sum()}-{(L&m).sum()}-{(T&m).sum()}"
            o[f'{k}回終了{st}_勝率']=wpct((W&m).sum(),(L&m).sum())
            o[f'{k}回終了{st}_試合']=m.sum()
    ex=x.innings>9
    o['延長W-L-T']=f"{(W&ex).sum()}-{(L&ex).sum()}-{(T&ex).sum()}";o['延長勝率']=wpct((W&ex).sum(),(L&ex).sum())
    o['完封勝']=(W&(x.RA==0)).sum();o['完封負']=(L&(x.R==0)).sum()
    o['ホーム勝率']=wpct((W&x.home).sum(),(L&x.home).sum());o['ビジター勝率']=wpct((W&~x.home).sum(),(L&~x.home).sum())
    o['交流戦勝率']=wpct((W&x.inter).sum(),(L&x.inter).sum())
    return pd.Series(o)
S=D.groupby(['year','team']).apply(summarize).reset_index()
S['league']=S.team.map(lambda t:'CL' if t in CL else 'PL'); S['name']=S.team.map(NAME)
S['rank']=S.groupby(['year','league'])['win%'].rank(ascending=False,method='min').astype(int)
S['Aclass']=S['rank']<=3
S.to_csv('team_season_summary.csv',index=False,encoding='utf-8-sig')
print(S[S.team=='d'][['year','G','W','L','T','win%','rank','RD','pyth%','pythW_diff']].to_string())
