import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
M=pd.read_csv('team_season_inning_metrics.csv'); Y=M[M.year<=2025].copy()
NM=Y[['team','name']].drop_duplicates().set_index('team').name.to_dict()
out=[]; L=[]
def two(cond_name,low,lbl):
    A=Y.Aclass; B=~A
    n=len(Y); a=(low&B).sum(); b=(low&A).sum(); c=(~low&B).sum(); dd=(~low&A).sum()
    r=dict(命題=lbl,低群n=int(low.sum()),**{'P(B|低)':a/low.sum(),'P(低|B)':a/B.sum(),'P(A|非低)':dd/(~low).sum(),'P(非低|A)':dd/A.sum(),
        '反例_低なのにA':int(b),'反例_非低なのにB':int(c),'低&B':int(a),'非低&A':int(dd)})
    ce=Y[low&A][['year','league','name','rank','R/G','off_scoring_rate','off_runs_per_scoring_inn','RA/G']].copy(); ce['反例種別']=f'{cond_name}なのにAクラス'
    ce2=Y[~low&B][['year','league','name','rank','R/G','off_scoring_rate','off_runs_per_scoring_inn','RA/G']].copy(); ce2['反例種別']=f'{cond_name}でないのにBクラス'
    return r,pd.concat([ce,ce2])
res=[];CE=[]
for nm,col,lbl in [('得点イニング率リーグ4-6位','off_scoring_rate_CL/PL順位','P2: 得点イニング率がリーグ下半分 → Bクラス'),
                   ('得点イニング当たり得点リーグ4-6位','off_runs_per_scoring_inn_CL/PL順位','P3: 得点イニング当たり得点がリーグ下半分 → Bクラス'),
                   ('得点/試合リーグ4-6位','R/G_CL/PL順位','参考: 得点/試合がリーグ下半分 → Bクラス'),
                   ('被得点イニング率リーグ4-6位','def_scoring_rate_CL/PL順位','参考: 被得点イニング率がリーグ下半分(悪い) → Bクラス')]:
    r,ce=two(nm,Y[col]>=4,lbl); res.append(r); CE.append(ce)
# both low
both=(Y['off_scoring_rate_CL/PL順位']>=4)&(Y['off_runs_per_scoring_inn_CL/PL順位']>=4)
r,ce=two('得点イニング率・得点イニング当たり得点ともに4-6位',both,'P2∧P3: 両方リーグ下半分 → Bクラス'); res.append(r); CE.append(ce)
R=pd.DataFrame(res); R.to_csv('propositions_2x2.csv',index=False,encoding='utf-8-sig'); print(R.round(3).to_string())
CEa=pd.concat(CE); CEa.to_csv('counterexamples.csv',index=False,encoding='utf-8-sig')
print(CEa[CEa['反例種別'].str.contains('得点イニング率リーグ4-6位|両方|ともに')].round(3).to_string())
# P1 Chunichi per-year dominant factor
D=pd.read_csv('decomposition_by_year.csv'); x=D[(D.side=='off')&(D.ref=='CL')&(D.year<=2025)]
print('SR dominant years',(x['得点イニング率'].abs()>x['得点イニング当たり得点'].abs()).sum(),'of',len(x), list(x.year[x['得点イニング率'].abs()>x['得点イニング当たり得点'].abs()]))
# among CL bottom-2 R/G team seasons (excluding chunichi): which factor
Z=Y.copy()
for (y,lg),t in Y.groupby(['year','league']):
    tot=t[['off_innings','off_scoring','off_runs','G']].sum()
    idx=t.index
    Z.loc[idx,'gSR']=np.log(t.off_scoring_rate/(tot.off_scoring/tot.off_innings)); Z.loc[idx,'gRPS']=np.log(t.off_runs_per_scoring_inn/(tot.off_runs/tot.off_scoring))
low=Z[(Z['R/G_CL/PL順位']>=5)]
low['SR主因']=low.gSR<low.gRPS
print('league 5-6th R/G team-seasons:',len(low),'SR main:',low['SR主因'].sum(), 'mean shares', round(low.gSR.sum()/(low.gSR.sum()+low.gRPS.sum()),3))
lo=low[low.team!='d']; print('excluding chunichi',len(lo),lo['SR主因'].sum(), round(lo.gSR.sum()/(lo.gSR.sum()+lo.gRPS.sum()),3))
# Chunichi ranks one-run share (high = more singles)
Y['one_rank']=Y.groupby(['year','league']).off_one_run_share.rank(ascending=False,method='min')
print('Chunichi one-run share CL rank (1=highest):',Y[Y.team=='d'].set_index('year').one_rank.astype(int).to_dict())
# park check: chunichi home/away scoring rate vs CL others' same split
for side in ('off','def'):
    d=M[(M.team=='d')&(M.year<=2025)]
    print(side, d[[f'{side}_scoring_rate_home_bat',f'{side}_scoring_rate_away_bat']].mean().round(3).to_dict())
