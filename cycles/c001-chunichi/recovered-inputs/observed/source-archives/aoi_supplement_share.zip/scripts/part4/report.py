import pandas as pd, numpy as np
M=pd.read_csv('team_season_inning_metrics.csv'); C=pd.read_csv('chunichi_vs_groups.csv',index_col=0)
Dc=pd.read_csv('decomposition_by_year.csv'); R=pd.read_csv('propositions_2x2.csv'); B=pd.read_csv('by_inning_comparison.csv',index_col=0); Bd=pd.read_csv('by_inning_comparison_def.csv',index_col=0)
P=pd.read_csv('park_check_CL_2013_2025.csv')
d=M[M.team=='d'].sort_values('year')
r=lambda v:f"({int(v)})"
L=[]
L.append("## A. 中日 年度別（攻撃）  カッコ=CL順位/NPB順位（1=良い）\n")
L.append("| 年 | 順位 | 得点/試合 | 攻撃イニング/試合 | 得点イニング率 | 得点イニング当たり得点 | 1点イニングの割合 | 1/2/3/4+点の内訳 | ビッグイニング率(3点以上) |")
L.append("|---|---|---|---|---|---|---|---|---|")
for _,x in d.iterrows():
    L.append(f"| {x.year}{'※' if x.year in (2020,2026) else ''} | {x['rank']} | {x['R/G']:.2f}{r(x['R/G_CL/PL順位'])}{r(x['R/G_NPB順位'])} | {x.off_innings_per_G:.2f} | {x.off_scoring_rate:.3f}{r(x['off_scoring_rate_CL/PL順位'])}{r(x['off_scoring_rate_NPB順位'])} | {x.off_runs_per_scoring_inn:.3f}{r(x['off_runs_per_scoring_inn_CL/PL順位'])}{r(x['off_runs_per_scoring_inn_NPB順位'])} | {x.off_one_run_share:.1%} | {x.off_r1_share:.0%}/{x.off_r2_share:.0%}/{x.off_r3_share:.0%}/{x.off_r4p_share:.0%} | {x.off_big_inning_rate:.3f}{r(x['off_big_inning_rate_CL/PL順位'])}{r(x['off_big_inning_rate_NPB順位'])} |")
L.append("\n## B. 中日 年度別（守備＝相手の攻撃）\n")
L.append("| 年 | 失点/試合 | 被得点イニング率 | 被得点イニング当たり失点 | 被1点イニングの割合 | 被ビッグイニング率 |"); L.append("|---|---|---|---|---|---|")
for _,x in d.iterrows():
    L.append(f"| {x.year} | {x['RA/G']:.2f}{r(x['RA/G_CL/PL順位'])}{r(x['RA/G_NPB順位'])} | {x.def_scoring_rate:.3f}{r(x['def_scoring_rate_CL/PL順位'])}{r(x['def_scoring_rate_NPB順位'])} | {x.def_runs_per_scoring_inn:.3f}{r(x['def_runs_per_scoring_inn_CL/PL順位'])}{r(x['def_runs_per_scoring_inn_NPB順位'])} | {x.def_one_run_share:.1%} | {x.def_big_inning_rate:.3f}{r(x['def_big_inning_rate_CL/PL順位'])}{r(x['def_big_inning_rate_NPB順位'])} |")
L.append("\n## C. 2013-2025平均：中日 vs 各グループ（チームシーズン単純平均）\n")
nm={'R/G':'得点/試合','off_innings_per_G':'攻撃イニング/試合','off_scoring_rate':'得点イニング率','off_runs_per_scoring_inn':'得点イニング当たり得点','off_one_run_share':'1点イニングの割合','off_r2_share':'2点イニングの割合','off_r3_share':'3点イニングの割合','off_r4p_share':'4点以上イニングの割合','off_big_inning_rate':'ビッグイニング率','off_scoreless_rate':'無得点イニング率',
    'RA/G':'失点/試合','def_innings_per_G':'守備イニング/試合','def_scoring_rate':'被得点イニング率','def_runs_per_scoring_inn':'被得点イニング当たり失点','def_one_run_share':'被1点イニングの割合','def_big_inning_rate':'被ビッグイニング率','def_scoreless_rate':'無失点イニング率'}
cols=list(C.columns)
L.append('| 指標 | '+' | '.join(cols)+' |'); L.append('|'+'---|'*(len(cols)+1))
for k,v in nm.items():
    L.append(f"| {v} | "+' | '.join('-' if pd.isna(C.loc[k,c]) else (f"{C.loc[k,c]:.1f}" if ('順位' in c or '年数' in c) else f"{C.loc[k,c]:.3f}") for c in cols)+' |')
L.append("\n## D. 回別の無得点率・ホーム/ビジター別の得点イニング率（2013-2025平均）\n")
L.append('| | '+' | '.join(B.columns)+' |'); L.append('|'+'---|'*(len(B.columns)+1))
order=[f'off_scoreless_{i}回' for i in range(1,10)]+['off_scoreless_10+回','off_scoring_rate_home_bat','off_scoring_rate_away_bat']
lab={**{f'off_scoreless_{i}回':f'攻撃 {i}回 無得点率' for i in range(1,10)},'off_scoreless_10+回':'攻撃 10回以降 無得点率','off_scoring_rate_home_bat':'得点イニング率（ホーム）','off_scoring_rate_away_bat':'得点イニング率（ビジター）'}
for k in order: L.append(f"| {lab[k]} | "+' | '.join(f"{B.loc[k,c]:.3f}" for c in B.columns)+' |')
for k in order:
    kd=k.replace('off_','def_'); L.append(f"| {lab[k].replace('攻撃','守備(相手)').replace('無得点率','無失点率').replace('得点イニング率（ホーム）','被得点イニング率（中日ビジター＝相手ホーム）').replace('得点イニング率（ビジター）','被得点イニング率（中日ホーム＝相手ビジター）')} | "+' | '.join(f"{Bd.loc[kd,c]:.3f}" for c in Bd.columns)+' |')
L.append("\n## E. 対数分解（中日 vs CL全体プール、log(中日/CL)）。得点/試合 = イニング/試合 × 得点イニング率 × 得点イニング当たり得点\n")
x=Dc[(Dc.side=='off')&(Dc.ref=='CL')]
L.append("| 年 | 中日 得点/試合 | CL 得点/試合 | log差（合計） | イニング数 | 得点イニング率 | 得点イニング当たり得点 | 主因 |"); L.append("|---|---|---|---|---|---|---|---|")
for _,y in x.iterrows():
    main='得点イニング率' if abs(y['得点イニング率'])>abs(y['得点イニング当たり得点']) else '得点イニング当たり得点'
    L.append(f"| {y.year} | {y['中日RG']:.2f} | {y['基準RG']:.2f} | {y.log_gap:+.3f} | {y['イニング数']:+.3f} | {y['得点イニング率']:+.3f} | {y['得点イニング当たり得点']:+.3f} | {main} |")
for ref in ('CL','NPB'):
  for side in ('off','def'):
    z=Dc[(Dc.side==side)&(Dc.ref==ref)&(Dc.year<=2025)][['log_gap','イニング数','得点イニング率','得点イニング当たり得点']].sum()
    L.append(f"\n- 2013-25合計（{'攻撃' if side=='off' else '守備'}、基準{ref}）: log差 {z.log_gap:+.3f} ＝ イニング数 {z['イニング数']:+.3f}（{z['イニング数']/z.log_gap:.0%}）＋ 得点イニング率 {z['得点イニング率']:+.3f}（{z['得点イニング率']/z.log_gap:.0%}）＋ 得点イニング当たり得点 {z['得点イニング当たり得点']:+.3f}（{z['得点イニング当たり得点']/z.log_gap:.0%}）")
L.append("\n## F. 命題検定の2×2表（NPB全体 2013-2025、156チームシーズン。「下半分」＝所属リーグ内4-6位）\n")
L.append("| 命題 | 該当n | P(B｜該当)＝命題 | P(該当｜B)＝逆 | P(A｜非該当)＝裏 | P(非該当｜A)＝対偶 | 反例: 該当なのにA | 反例: 非該当なのにB |"); L.append("|---|---|---|---|---|---|---|---|")
for _,y in R.iterrows():
    L.append(f"| {y['命題']} | {y['低群n']} | {y['P(B|低)']:.3f} | {y['P(低|B)']:.3f} | {y['P(A|非低)']:.3f} | {y['P(非低|A)']:.3f} | {y['反例_低なのにA']} | {y['反例_非低なのにB']} |")
L.append("\n## G. 本拠地の影響の簡易チェック（CL 2013-2025、半イニング単位）\n")
L.append("| 球団 | 攻/守 | 得点イニング率 全体 | ナゴヤ開催の試合 | ナゴヤと自球団本拠を除く試合 | 1イニング当たり得点 全体 | ナゴヤ | ナゴヤ・自本拠を除く |"); L.append("|---|---|---|---|---|---|---|---|")
NM={'c':'広島','d':'中日','db':'DeNA','g':'巨人','s':'ヤクルト','t':'阪神'}
for _,y in P.iterrows():
    L.append(f"| {NM[y.team]} | {'攻撃' if y.side=='off' else '守備'} | {y.SR_all:.3f} | {y.SR_nagoya:.3f} | {y.SR_excl_Nagoya_and_own_home:.3f} | {y.RPI_all:.3f} | {y.RPI_nagoya:.3f} | {y.RPI_neutral:.3f} |")
open('report_tables.md','w').write('\n'.join(L)); print('ok')
