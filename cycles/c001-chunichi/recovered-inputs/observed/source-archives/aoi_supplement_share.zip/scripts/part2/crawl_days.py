import os, re, sys, time, datetime, requests
S=requests.Session(); S.headers['User-Agent']='Mozilla/5.0 (personal research; polite crawler, ~2 req/s)'
RAW='/workspace/dragons_analysis/part2/raw'
def hasgames(t): return ('contentsRuns' in t) or ('score_left' in t)
def fetch(url):
    for t in range(4):
        try:
            r=S.get(url,timeout=30); time.sleep(0.4)
            if r.status_code==404: return None
            if r.ok: r.encoding='utf-8'; return r.text
        except Exception as e: print('ERR',url,e,flush=True)
        time.sleep(5*(t+1))
    return None
def day(year,fn,probe=False):
    p=f'{RAW}/{year}/days/{fn}'
    if os.path.exists(p): return open(p,encoding='utf-8').read()
    t=fetch(f'https://npb.jp/bis/{year}/games/{fn}')
    if t is None or not hasgames(t): return None
    os.makedirs(os.path.dirname(p),exist_ok=True); open(p,'w',encoding='utf-8').write(t); return t
for year in map(int,sys.argv[1:]):
    d=datetime.date(year,3,15) if year!=2020 else datetime.date(2020,6,15)
    first=None
    while first is None and d.month<8:
        fn=f'gm{d:%Y%m%d}.html'
        if day(year,fn): first=fn
        else: d+=datetime.timedelta(1)
    fn=first; n=0
    while fn:
        s=day(year,fn)
        if s is None:
            t=fetch(f'https://npb.jp/bis/{year}/games/{fn}') or ''
            m=re.search(r'<a href="(?:\./)?(gm\d{8}\.html)">次の試合',t)
            print('nogames',fn,flush=True)
            if m and m.group(1)!=fn: fn=m.group(1); continue
            dd=datetime.datetime.strptime(fn[2:10],'%Y%m%d').date(); fn=None
            for k in range(1,15):
                f2=f'gm{dd+datetime.timedelta(k):%Y%m%d}.html'
                if day(year,f2): fn=f2; break
            continue
        n+=1
        m=re.search(r'<a href="(?:\./)?(gm\d{8}\.html)">次の試合',s)
        fn=m.group(1) if m else None
    print(year,first,n,flush=True)
