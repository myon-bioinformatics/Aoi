import json, pandas as pd, numpy as np
from collections import Counter
P2='/workspace/dragons_analysis/part2'
G={g['url']:g for g in json.load(open(f'{P2}/games_raw.json'))}
D=pd.read_csv(f'{P2}/team_games.csv')
norm=lambda c:'b' if c=='bs' else c
rows=[]; cellkinds=Counter(); mism=0; called=0
for _,x in D.iterrows():
    g=G[x.url]
    side='home' if x.home else 'away'; opp='away' if x.home else 'home'
    me=g[side+'_inn']; op=g[opp+'_inn']
    for v in me+op: cellkinds[type(v).__name__ if not isinstance(v,str) else 'str:'+v]+=1
    if sum(v for v in me if isinstance(v,int))!=g[side+'_R'] or sum(v for v in op if isinstance(v,int))!=g[opp+'_R']: mism+=1
    if max(len(me),len(op))<9: called+=1
    for who,arr in (('off',me),('def',op)):
        for i,v in enumerate(arr):
            if not isinstance(v,int): continue   # 'X' (unplayed bottom) / None (not played)
            rows.append((x.year,x.team,x.league,bool(x.home)==(who=='off'),who,i+1,v,x.url))
I=pd.DataFrame(rows,columns=['year','team','league','batting_home','side','inning','runs','url'])
I.to_csv('team_half_innings.csv.gz',index=False,compression='gzip')
print('team-games',len(D),'cell kinds',cellkinds,'sum mismatches',mism,'games<9 innings (team-side rows)',called)
