import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
P2='/workspace/dragons_analysis/part2'
I=pd.read_csv('team_half_innings.csv.gz')
S=pd.read_csv(f'{P2}/team_season_summary.csv')[['year','team','name','league','G','W','L','T','win%','rank','Aclass','R','RA']]
def agg(x):
    n=len(x); r=x.runs; sc=(r>0)
    o=dict(innings=n, scoring=sc.sum(), runs=r.sum(), r1=(r==1).sum(), r2=(r==2).sum(), r3=(r==3).sum(), r4p=(r>=4).sum())
    return pd.Series(o)
A=I.groupby(['year','team','side']).apply(agg).reset_index()
def rates(df):
    df['scoring_rate']=df.scoring/df.innings
    df['scoreless_rate']=1-df.scoring_rate
    df['one_run_share']=df.r1/df.scoring
    for k in ['r1','r2','r3','r4p']: df[k+'_share']=df[k]/df.scoring
    df['runs_per_scoring_inn']=df.runs/df.scoring
    df['big_inning_rate']=(df.r3+df.r4p)/df.innings
    df['runs_per_inning']=df.runs/df.innings
    return df
A=rates(A)
W=A.pivot_table(index=['year','team'],columns='side',values=[c for c in A.columns if c not in('year','team','side')]).reset_index()
W.columns=['year','team']+[f'{b}_{a}' for a,b in W.columns[2:]]
M=S.merge(W,on=['year','team'])
M['off_innings_per_G']=M.off_innings/M.G; M['def_innings_per_G']=M.def_innings/M.G
M['R/G']=M.R/M.G; M['RA/G']=M.RA/M.G
assert (M.off_runs==M.R).all() and (M.def_runs==M.RA).all()
# by inning number & home/away (offense)
I['inn_lbl']=I.inning.clip(upper=10).map(lambda i:str(i) if i<=9 else '10+')
B=I.groupby(['year','team','side','inn_lbl']).runs.apply(lambda r:(r==0).mean()).unstack('inn_lbl')
B.columns=[f'scoreless_{c}回' for c in B.columns]; B=B.reset_index()
H=I.groupby(['year','team','side','batting_home']).runs.apply(lambda r:(r>0).mean()).unstack('batting_home')
H.columns=['scoring_rate_away_bat','scoring_rate_home_bat']; H=H.reset_index()
BH=B.merge(H,on=['year','team','side'])
BH.to_csv('by_inning_home_away.csv',index=False,encoding='utf-8-sig')
for side in ('off','def'):
    t=BH[BH.side==side].drop(columns='side'); t.columns=['year','team']+[f'{side}_{c}' for c in t.columns[2:]]
    M=M.merge(t,on=['year','team'])
# ranks
KEYS=['R/G','off_innings_per_G','off_scoring_rate','off_runs_per_scoring_inn','off_one_run_share','off_big_inning_rate','off_scoreless_rate',
      'RA/G','def_innings_per_G','def_scoring_rate','def_runs_per_scoring_inn','def_one_run_share','def_big_inning_rate','def_scoreless_rate']
# higher is better? offense: R/G, scoring_rate, rpsi, big +; scoreless -, one_run_share neutral(None); innings neutral. defense reversed
HB={'R/G':1,'off_scoring_rate':1,'off_runs_per_scoring_inn':1,'off_big_inning_rate':1,'off_scoreless_rate':0,
    'RA/G':0,'def_scoring_rate':0,'def_runs_per_scoring_inn':0,'def_big_inning_rate':0,'def_scoreless_rate':1}
for c,hb in HB.items():
    M[c+'_CL/PL順位']=M.groupby(['year','league'])[c].rank(ascending=(hb==0),method='min')
    M[c+'_NPB順位']=M.groupby('year')[c].rank(ascending=(hb==0),method='min')
M.to_csv('team_season_inning_metrics.csv',index=False,encoding='utf-8-sig')
print(M[M.team=='d'][['year','rank','R/G','off_innings_per_G','off_scoring_rate','off_runs_per_scoring_inn','off_one_run_share','off_big_inning_rate','off_scoring_rate_NPB順位','off_runs_per_scoring_inn_NPB順位','def_scoring_rate','def_runs_per_scoring_inn']].round(3).to_string())
