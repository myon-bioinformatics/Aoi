#!/bin/bash
# Reconstructed from the shell one-liner actually used (2026-10-03) to fetch NPB official team totals for verify_official.py
mkdir -p /workspace/dragons_analysis/part2/raw/official && cd /workspace/dragons_analysis/part2/raw/official
for y in $(seq 2013 2025); do for p in std_c std_p tmb_c tmb_p tmp_c tmp_p; do
  [ -s ${y}_$p.html ] || { curl -s -o ${y}_$p.html https://npb.jp/bis/$y/stats/$p.html; sleep 0.5; }
done; done
