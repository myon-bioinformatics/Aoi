import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
M=pd.read_csv('team_season_metrics.csv')
K=[('1点差勝率',1),('2点差勝率',1),('3点差以上勝率',1),('逆転勝/G',1),('逆転勝率(勝利中)',None),('逆転負率(敗戦中)',0),('ビハインド経験試合の勝率',1),('13回得失差/G',1),('46回得失差/G',1),('79回得失差/G',1),
   ('5回終了リード率',1),('5回終了リード_勝率',1),('7回終了リード率',1),('7回終了リード_勝率',1),('ビジター勝率',1),('ホーム勝率',1),('pythW_diff',1),('R/G',1),('RA/G',0),('RD/G',1),('win%',1),('勝利中1点差の割合',None),('勝利中4点以上差の割合',None)]
for c,hb in K:
    if hb is None: continue
    M[c+'_NPB順位']=M.groupby('year')[c].rank(ascending=(hb==0),method='min')
M.to_csv('team_season_metrics_npb.csv',index=False,encoding='utf-8-sig')
Y=M[M.year<=2025]; d=Y[Y.team=='d']
cols=[c for c,_ in K]
grp={'中日':d,'NPB全体':Y,'NPB Aクラス':Y[Y.Aclass],'NPB Bクラス':Y[~Y.Aclass],'NPB Bクラス(中日除く)':Y[~Y.Aclass&(Y.team!='d')],
     'CL Aクラス':Y[Y.Aclass&(Y.league=='CL')],'PL Aクラス':Y[Y.Aclass&(Y.league=='PL')],'CL Bクラス':Y[~Y.Aclass&(Y.league=='CL')],'PL Bクラス':Y[~Y.Aclass&(Y.league=='PL')]}
C=pd.DataFrame({k:v[cols].mean() for k,v in grp.items()})
C['中日の平均NPB順位(12球団)']=[d[c+'_NPB順位'].mean() if c+'_NPB順位' in d else np.nan for c in cols]
C['中日がNPB10-12位の年数/13']=[(d[c+'_NPB順位']>=10).sum() if c+'_NPB順位' in d else np.nan for c in cols]
C['中日がNPB下半分(7-12位)の年数/13']=[(d[c+'_NPB順位']>=7).sum() if c+'_NPB順位' in d else np.nan for c in cols]
C.to_csv('npb12_comparison.csv',encoding='utf-8-sig')
R=M[M.team=='d'][['year','rank']+[c+'_NPB順位' for c,hb in K if hb is not None]]
R.columns=[x.replace('_NPB順位','') for x in R.columns]
R.to_csv('chunichi_npb12_ranks.csv',index=False,encoding='utf-8-sig')
pd.set_option('display.width',300)
print(C.round(3).to_string()); print(R.to_string())
# A/B separation power: which metrics best separate A vs B (standardized diff), NPB-wide
sep={c:(Y[Y.Aclass][c].mean()-Y[~Y.Aclass][c].mean())/Y[c].std() for c in cols}
print(pd.Series(sep).sort_values().round(2))
X=pd.read_csv('counterexamples.csv'); print(X[X.league=='PL'].to_string())
print(X.groupby(['league','tags']).size())
