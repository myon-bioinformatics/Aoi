import re,html,os,csv,json
from gamelist import games
def cellval(v):
    v=html.unescape(re.sub(r'<[^>]+>','',v)).strip().replace('\u3000','')
    if v in ('','-'): return None
    if v.lower()=='x': return 'X'
    m=re.match(r'^(\d+)[xX]?$',v)
    return int(m.group(1)) if m else v
NM=[('DeNA','db'),('中日','d'),('阪神','t'),('読売','g'),('巨人','g'),('広島','c'),('ヤクルト','s'),('西武','l'),('日本ハム','f'),('ロッテ','m'),('オリックス','b'),('ソフトバンク','h'),('楽天','e')]
def name2code(n):
    n=re.sub(r'\s|\u3000','',html.unescape(n))
    for k,c in NM:
        if k in n: return c
    raise ValueError('team '+n)
def parse_old(s):
    title=re.search(r'<title>([^<]*)',s).group(1)
    if 'id="gmdivresult"' not in s: return dict(title=title,away=None,home=None,away_inn=[],home_inn=[],away_R=None,home_R=None,status='cancelled')
    i=s.find('id="gmdivresult"'); j=s.find('</table>',i); t=s[i:j]
    rows=re.findall(r'<tr><td class="gmscoreteam">(.*?)</td>(.*?)</tr>',t,re.S)
    lines=[]
    for name,cells in rows:
        cs=re.findall(r'<td[^>]*class="(gmscore|gmscspan)"[^>]*>(.*?)</td>',cells,re.S)
        vals=[c[1] for c in cs if c[0]=='gmscore']
        # last 3 = R H E, before that '-' separator
        rhe=[cellval(v) for v in vals[-3:]]
        inn=[cellval(v) for v in vals[:-4]]
        if vals[-4].strip()!='-' or not vals[-3].strip().isdigit():
            return dict(title=title,away=None,home=None,away_inn=[],home_inn=[],away_R=None,home_R=None,status='noGame')
        lines.append((inn,rhe))
    status='final'
    codes=[name2code(n) for n,_ in rows]
    return dict(title=title,away=codes[0],home=codes[1],away_inn=lines[0][0],home_inn=lines[1][0],away_R=lines[0][1][0],home_R=lines[1][1][0],status=status)
def parse_new(s):
    h3=re.search(r'<h3>(.*?)</h3>',s,re.S).group(1); title=' '.join(h3.split())
    gi=re.search(r'<p class="game_info">(.*?)</p>',s,re.S).group(1)
    status='final' if ('試合終了' in gi or 'コールド' in gi) else ('noGame' if '中止' in gi or 'ノーゲーム' in gi else 'other:'+' '.join(gi.split())[:30])
    t=s[s.find('id="tablefix_ls"'):]; t=t[:t.find('</table>')]
    out={}
    for cls in ('top','bottom'):
        m=re.search(r'<tr class="%s">(.*?)</tr>'%cls,t,re.S).group(1)
        code=re.search(r'flag_([a-z]+)_\d{4}',m).group(1)
        tds=re.findall(r'<td( class="[^"]*")?>(.*?)</td>',m,re.S)
        inn=[cellval(v) for c,v in tds if not c]
        R=[cellval(v) for c,v in tds if 'total-1' in c][0]
        out[cls]=(code,inn,R)
    return dict(title=title,away=out['top'][0],home=out['bottom'][0],away_inn=out['top'][1],home_inn=out['bottom'][1],away_R=out['top'][2],home_R=out['bottom'][2],status=status)
def main():
    rows=[];bad=[]
    for g in games():
        if not os.path.exists(g['file']): continue
        s=open(g['file'],encoding='utf-8').read()
        try:
            d=parse_old(s) if g['year']<=2025 else parse_new(s)
        except Exception as e:
            bad.append((g['url'],repr(e)[:100])); continue
        # trim trailing None innings (unplayed extra columns)
        for k in ('away_inn','home_inn'):
            while d[k] and d[k][-1] is None: d[k].pop()
        ok=lambda inn,R: sum(v for v in inn if isinstance(v,int))==R
        d['check']=ok(d['away_inn'],d['away_R']) and ok(d['home_inn'],d['home_R'])
        d.update(year=g['year'],date=g['date'],url=g['url'])
        rows.append(d)
    json.dump(rows,open('games_raw.json','w'),ensure_ascii=False)
    print(len(rows),'parsed; bad',len(bad)); [print(b) for b in bad[:20]]
    print('sumcheck fail',sum(not r['check'] for r in rows))
    from collections import Counter
    print(Counter(r['status'] for r in rows)); print(Counter('公式戦' in r['title'] for r in rows))
if __name__=='__main__': main()
