# V2保存版の検証範囲

V2は保存先の版です。全データがV2相当に検証された、という意味ではありません。

- `season.jsonl`: `data`はV1入力のままです。`fields`に各指標の出所・検証範囲・スキップ理由を記録しています。
- `annual-recalculated.jsonl`: 今回再計算したV2の値です。ただし元の年間合計はV1を信頼した入力です。
- `propositions.jsonl` / `sets.jsonl`: 成功receiptがある出力だけV2再判定と記録します。スキップ・失敗はV1を注釈付きで保持します。
- `verification-summary.json`: 検証・継承・欠損の件数、入力と証拠のSHA-256、実行版、式を確認できます。

`equivalent=V2`は記載されたverification_scope内だけです。元データの正しさや命題の成立を保証しません。
`value_origin=V1, verification_status=verified`は、旧値を残したまま年間式の整合性を確認した状態です。
`skipped`は未検証の継承、`unavailable`は値なし、`failed`は実行不具合、`different`は不一致です。
いずれも検証成功の件数には足しません。V1にもない値は推定して埋めません。
継承入力の食い違い・成功記録と入力欠落の矛盾はエラーです。正当な未実行はV1を残します。
CLIは注釈保存に成功しても、実行失敗なら64、不一致なら1で終了します。スキップだけなら0です。

このディレクトリのdata+verificationを一緒に利用してください。親ディレクトリのJSONLは比較用の未注釈原本です。
